<div style="text-align: center">Click to <?php
	$form->AddInputPart("hide");
?> or <?php
	$form->AddInputPart("show");
?> the form.</div>
<br />
<center><table style="width: 24em">
<tr>
<td style="font-weight: bold; width: 1%">Feedback:</td>
<td id="feedback" style="border-width: 1px; border-style: solid; border-top-color: #868686; border-right-color: #F9F9F9; border-bottom-color: #F9F9F9; border-left-color: #868686; padding: 3px">Click in the show or hide buttons</td>
</table></center>
<br />
<center><table id="wholeform" style="border-width: 1px; border-style: solid; background-color: #c0c0c0; border-top-color: #F9F9F9; border-right-color: #868686; border-bottom-color: #868686; border-left-color: #F9F9F9; padding: 0px;">
<tr>
<td style="background-color: #000080; padding: 2px; color: #ffffff;  font-weight: bold">Form class animation test</td>
</tr>

<tr>
<td><fieldset>
<legend style="font-weight: bold">Example form would show here</legend>
<div style="text-align: center; padding: 2px">Some fields would go here.</div>
</fieldset></td>
</tr>
</table></center>
