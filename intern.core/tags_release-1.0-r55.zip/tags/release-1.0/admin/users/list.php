<?php
  echo "<h2>Utilisateurs</h2>";
  $users = new list_users();
  $users->show();
?>
