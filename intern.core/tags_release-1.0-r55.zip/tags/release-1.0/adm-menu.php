<?php
echo '
    <form class="inline" method="post" action="?contenu=admin&page=users">
      <input type="submit" value="Utilisateurs">
    </form>
    <form class="inline" method="post" action="?contenu=admin&page=compta">
      <input type="submit" value="Comptabilitée">
    </form>
    <form class="inline" method="post" action="?contenu=admin&page=factures">
      <input type="submit" value="Suppression Factures">
    </form>
    <form class="inline" method="post" action="?contenu=admin&page=clients">
      <input type="submit" value="Clients">
    </form>
    <form class="inline" method="post" action="?contenu=admin&page=tpl">
      <input type="submit" value="Modele">
    </form>
    ';
?>
