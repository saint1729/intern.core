<?php

print("
	<div id=\"menu\">
		<ul id=\"$content\">
			<li id=\"li-user\"><a href=\"./index.php?contenu=viewuser\">Gérer mon profil utilisateur</a></li>
			<li id=\"li-orga\"><a href=\"./index.php?contenu=viewtask\">Gérer mes tâches</a></li>
			<li id=\"li-forma\"><a href=\"./index.php?contenu=viewcustomers\">Gérer les clients</a></li>
			<li id=\"li-quitter\"><a href=\"./index.php?contenu=quitter\">Quitter</a></li>
		</ul>
	</div>
</div>
<span class='clear'>&nbsp</span>
");
?>
  
