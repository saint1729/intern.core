<?php
  if (isset($login)) {
    echo "<div id=\"login\">$login</div>";
  }
?>
<div id = "titre">
	<img src="./images/baniere.jpg" width="800" height="99" alt="Inforezo votre administrateur réseau"/>
