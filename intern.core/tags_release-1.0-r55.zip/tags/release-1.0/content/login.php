<div class="formlogin"> 
	<form action="./index2.php?contenu=veriflogin" method='post'>
		<table align="center" border="0">
			<tr>
				<td>Login :</td>
				<td><input type="text" name="login" maxlength="50"></td>
			</tr>
			<tr>
				<td>Password</td>
				<td><input type="password"name="pass" maxlength="50"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" value="login"></td>
			</tr>
		</table>
	</form>
</div>
