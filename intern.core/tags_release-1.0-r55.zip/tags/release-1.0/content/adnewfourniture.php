<?php
	echo MakeFormFourniture();
?> 
