<div class="bandeau">
	<h1>CLIENTS</h1>
	<h2>Nouveau Client</h2>
</div>
<?php
	$client= new client();
	echo $client->edit();
?>	
