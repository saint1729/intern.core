<?php
	$int_id = $_POST["int_id"];
	echo MakeFormTask($int_id)
?>
