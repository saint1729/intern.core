<?php
	$affectation = new affectation($_POST['cli_id']);
	echo $affectation-> add_new();
?>
