<div class="presentation">
	Désolé cette fonction n'est pas encore opérationnelle 
	<a class="bouton" href="index2.php?contenu=viewcustomers">Retour</a>
</div>
