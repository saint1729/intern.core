<?php
//G�n�ration du fichier de d�finition de police pour le tutoriel 7
require('../font/makefont/makefont.php');

MakeFont('calligra.ttf','calligra.afm');
?>
