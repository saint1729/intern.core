<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<META name="description" content="Guidance, le magazine en ligne de la formation">    <META name="keywords" content="phpmyvisite, phpmyvisit, phpmyvisits, phpmyvisites, php, inforezo, devis, information, intervention, facturation, loire, fiche, st etienne">    <META name="robots" content="all">    <META name="revisit-after" content="4 day">    <META http-equiv="Content-Language" content="fr">    <META name="author" content="Yohann Rebattu">    <meta http-equiv="content-language" content="fr">
     <LINK href="style.css" rel="stylesheet" type="text/css" >
    <title>
     <?php echo SOCIETE ;?> 
    </title>
  </head>
  <body>

