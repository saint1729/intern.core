<?php
echo'
<div class="fintext">Un problème, une suggestion n\'hésitez pas à m\'envoyer un email: <a href="mailto:yohann@inforezo.com">yohann@inforezo.com</a></div>';
echo'
<!-- phpmyvisites -->
<a href="http://www.phpmyvisites.net/" title="phpMyVisites | Open source web analytics"
onclick="window.open(this.href);return(false);">
<script type="text/javascript">
<!--
var a_vars = Array();
var pagename=\'\';

var phpmyvisitesSite = 4;
var phpmyvisitesURL = "http://82.127.50.113/phpmv2/phpmyvisites.php";
//-->
</script>
<script language=javascript src="http://82.127.50.113/phpmv2/phpmyvisites.js" type="text/javascript"></script>
<noscript>
<p>phpMyVisites | Open source web analytics
<img src="http://82.127.50.113/phpmv2/phpmyvisites.php" alt="phpMyVisites" style="border:0" />
</p>
</noscript>
</a>
<!-- /phpmyvisites -->';
echo'  </body>
</html>
';
?>
